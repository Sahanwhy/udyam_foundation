<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  Udyam Foundation — Gallery PHP API
 *  Runs on GoDaddy hosting alongside the images/ folder.
 *  Handles: list, upload, delete, featured, categories, descriptions.
 * ═══════════════════════════════════════════════════════════
 */

require_once __DIR__ . '/config.php';

// ── CORS ───────────────────────────────────────────────────
$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
$allowedOrigin = '';

foreach (CORS_ORIGINS as $allowed) {
    if ($origin && strpos($origin, $allowed) === 0) {
        $allowedOrigin = $origin;
        break;
    }
}

if ($allowedOrigin) {
    header("Access-Control-Allow-Origin: $allowedOrigin");
    header("Access-Control-Allow-Credentials: true");
}

header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=utf-8");

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ── JWT Helper ─────────────────────────────────────────────

function base64UrlDecode($data) {
    $remainder = strlen($data) % 4;
    if ($remainder) {
        $data .= str_repeat('=', 4 - $remainder);
    }
    return base64_decode(strtr($data, '-_', '+/'));
}

function verifyJWT($token) {
    $parts = explode('.', $token);
    if (count($parts) !== 3) return null;

    list($headerB64, $payloadB64, $signatureB64) = $parts;

    // Verify signature (HS256)
    $signature = base64UrlDecode($signatureB64);
    $expected = hash_hmac('sha256', "$headerB64.$payloadB64", JWT_SECRET, true);

    if (!hash_equals($expected, $signature)) {
        return null; // Invalid signature
    }

    $payload = json_decode(base64UrlDecode($payloadB64), true);
    if (!$payload) return null;

    // Check expiration
    if (isset($payload['exp']) && $payload['exp'] < time()) {
        return null; // Expired
    }

    return $payload;
}

function requireAuth() {
    $authHeader = '';
    
    // Method 1: Standard
    if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
    }
    // Method 2: Redirect (set by .htaccess RewriteRule on GoDaddy/shared hosting)
    elseif (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $authHeader = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    }
    // Method 3: Apache request headers function
    elseif (function_exists('apache_request_headers')) {
        $headers = apache_request_headers();
        foreach ($headers as $key => $value) {
            if (strtolower($key) === 'authorization') {
                $authHeader = $value;
                break;
            }
        }
    }
    // Method 4: Check getallheaders (alias)
    elseif (function_exists('getallheaders')) {
        $headers = getallheaders();
        foreach ($headers as $key => $value) {
            if (strtolower($key) === 'authorization') {
                $authHeader = $value;
                break;
            }
        }
    }

    if (!$authHeader || strpos($authHeader, 'Bearer ') !== 0) {
        http_response_code(401);
        echo json_encode(['error' => 'Authentication required']);
        exit;
    }

    $token = substr($authHeader, 7);
    $user = verifyJWT($token);

    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid or expired token']);
        exit;
    }

    return $user;
}

// ── Data Store (JSON file) ─────────────────────────────────

function loadData() {
    if (!file_exists(DATA_FILE)) {
        return ['photos' => [], 'categories' => []];
    }
    $json = file_get_contents(DATA_FILE);
    $data = json_decode($json, true);
    if (!$data) {
        return ['photos' => [], 'categories' => []];
    }
    // Ensure keys exist
    if (!isset($data['photos'])) $data['photos'] = [];
    if (!isset($data['categories'])) $data['categories'] = [];
    return $data;
}

function saveData($data) {
    // Use LOCK_EX to prevent concurrent write corruption
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    file_put_contents(DATA_FILE, $json, LOCK_EX);
}

function generateId() {
    return bin2hex(random_bytes(12)); // 24-char hex string like MongoDB ObjectId
}

// ── Sanitize category name for filesystem ──────────────────

function sanitizeFolderName($name) {
    return preg_replace('/[<>:"\/\\\\|?*]/', '_', trim($name));
}

// ── Route Handling ─────────────────────────────────────────

$action = isset($_GET['action']) ? $_GET['action'] : '';
$method = $_SERVER['REQUEST_METHOD'];

switch ($action) {

    // ────────────────────────────────────────────────────────
    // GET: List all photos
    // ────────────────────────────────────────────────────────
    case 'list':
        if ($method !== 'GET') { http_response_code(405); echo json_encode(['error' => 'Method not allowed']); exit; }
        
        $data = loadData();
        $photos = $data['photos'];

        // Optional filters
        $filterCategory = isset($_GET['category']) ? $_GET['category'] : '';
        $filterFeatured = isset($_GET['featured']) ? $_GET['featured'] : '';

        if ($filterCategory) {
            $photos = array_values(array_filter($photos, function($p) use ($filterCategory) {
                return isset($p['category']) && $p['category'] === $filterCategory;
            }));
        }

        if ($filterFeatured === 'true') {
            $photos = array_values(array_filter($photos, function($p) {
                return !empty($p['featured']);
            }));
        }

        // Sort by date descending (newest first)
        usort($photos, function($a, $b) {
            $da = isset($a['date']) ? $a['date'] : '';
            $db = isset($b['date']) ? $b['date'] : '';
            return strcmp($db, $da);
        });

        echo json_encode($photos);
        break;

    // ────────────────────────────────────────────────────────
    // GET: List unique categories
    // ────────────────────────────────────────────────────────
    case 'categories':
        if ($method !== 'GET') { http_response_code(405); echo json_encode(['error' => 'Method not allowed']); exit; }
        
        $data = loadData();
        $cats = [];
        foreach ($data['photos'] as $photo) {
            if (!empty($photo['category']) && !in_array($photo['category'], $cats)) {
                $cats[] = $photo['category'];
            }
        }
        sort($cats);
        echo json_encode($cats);
        break;

    // ────────────────────────────────────────────────────────
    // GET: Category descriptions map
    // ────────────────────────────────────────────────────────
    case 'category-descriptions':
        if ($method !== 'GET') { http_response_code(405); echo json_encode(['error' => 'Method not allowed']); exit; }
        
        $data = loadData();
        $descMap = [];
        foreach ($data['categories'] as $cat) {
            if (!empty($cat['category'])) {
                $descMap[$cat['category']] = isset($cat['description']) ? $cat['description'] : '';
            }
        }
        echo json_encode($descMap);
        break;

    // ────────────────────────────────────────────────────────
    // POST: Upload photo(s) — saves to images/<category>/
    // ────────────────────────────────────────────────────────
    case 'upload':
        if ($method !== 'POST') { http_response_code(405); echo json_encode(['error' => 'Method not allowed']); exit; }
        
        $user = requireAuth();

        $category = isset($_POST['category']) ? trim($_POST['category']) : 'Uncategorized';
        $date = isset($_POST['date']) ? trim($_POST['date']) : (isset($_POST['year']) ? trim($_POST['year']) : '');
        $featured = isset($_POST['featured']) && ($_POST['featured'] === 'true' || $_POST['featured'] === '1');
        $description = isset($_POST['categoryDescription']) ? trim($_POST['categoryDescription']) : 
                       (isset($_POST['description']) ? trim($_POST['description']) : '');

        // Validate files
        if (!isset($_FILES['photos']) || empty($_FILES['photos']['name'][0])) {
            http_response_code(400);
            echo json_encode(['error' => 'No photos provided']);
            exit;
        }

        $files = $_FILES['photos'];
        $fileCount = is_array($files['name']) ? count($files['name']) : 1;

        // Create category folder
        $safeFolder = sanitizeFolderName($category);
        $folderPath = IMAGES_DIR . '/' . $safeFolder;
        if (!is_dir($folderPath)) {
            mkdir($folderPath, 0755, true);
        }

        $data = loadData();
        $savedPhotos = [];

        for ($i = 0; $i < $fileCount; $i++) {
            $name = is_array($files['name']) ? $files['name'][$i] : $files['name'];
            $tmpName = is_array($files['tmp_name']) ? $files['tmp_name'][$i] : $files['tmp_name'];
            $error = is_array($files['error']) ? $files['error'][$i] : $files['error'];
            $size = is_array($files['size']) ? $files['size'][$i] : $files['size'];

            // Skip empty slots
            if ($error === UPLOAD_ERR_NO_FILE) continue;

            if ($error !== UPLOAD_ERR_OK) {
                continue; // Skip errored files
            }

            if ($size > MAX_FILE_SIZE) {
                continue; // Skip oversized files
            }

            // Validate extension
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (!in_array($ext, ALLOWED_EXTENSIONS)) {
                continue; // Skip disallowed types
            }

            // Generate unique filename
            $baseName = preg_replace('/\s+/', '_', pathinfo($name, PATHINFO_FILENAME));
            $baseName = preg_replace('/[^a-zA-Z0-9_\-]/', '', $baseName);
            if (!$baseName) $baseName = 'photo';
            $unique = time() . '_' . mt_rand(1000, 9999);
            $newFilename = "{$baseName}_{$unique}.{$ext}";
            $destPath = $folderPath . '/' . $newFilename;

            if (move_uploaded_file($tmpName, $destPath)) {
                // Build relative URL: images/<category>/<filename>
                $imageUrl = "images/{$safeFolder}/{$newFilename}";

                $photoRecord = [
                    '_id' => generateId(),
                    'title' => '',
                    'category' => $category,
                    'imageUrl' => $imageUrl,
                    'featured' => $featured,
                    'date' => $date,
                ];

                $data['photos'][] = $photoRecord;
                $savedPhotos[] = $photoRecord;
            }
        }

        if (count($savedPhotos) === 0) {
            http_response_code(400);
            echo json_encode(['error' => 'No valid photos were uploaded. Check file types (jpg, png, webp, gif, heic) and size (max 20MB).']);
            exit;
        }

        // Save/update category description if provided
        if ($description && $category) {
            $found = false;
            foreach ($data['categories'] as &$cat) {
                if (isset($cat['category']) && strtolower($cat['category']) === strtolower($category)) {
                    $cat['description'] = $description;
                    $cat['category'] = $category; // sync casing
                    $cat['updatedAt'] = date('c');
                    $found = true;
                    break;
                }
            }
            unset($cat);
            if (!$found) {
                $data['categories'][] = [
                    'category' => $category,
                    'description' => $description,
                    'updatedAt' => date('c'),
                ];
            }
        }

        saveData($data);

        echo json_encode([
            'success' => true,
            'message' => "Uploaded " . count($savedPhotos) . " photo(s) successfully",
            'photos' => $savedPhotos,
            'photo' => $savedPhotos[0],
        ]);
        break;

    // ────────────────────────────────────────────────────────
    // POST: Delete a single photo
    // ────────────────────────────────────────────────────────
    case 'delete':
        if ($method !== 'POST') { http_response_code(405); echo json_encode(['error' => 'Method not allowed']); exit; }
        
        $user = requireAuth();

        $input = json_decode(file_get_contents('php://input'), true);
        $id = isset($input['id']) ? $input['id'] : (isset($_POST['id']) ? $_POST['id'] : '');

        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'Photo ID is required']);
            exit;
        }

        $data = loadData();
        $found = false;
        $newPhotos = [];

        foreach ($data['photos'] as $photo) {
            if (isset($photo['_id']) && $photo['_id'] === $id) {
                $found = true;
                // Delete file from disk
                if (!empty($photo['imageUrl']) && strpos($photo['imageUrl'], 'http') !== 0) {
                    $filePath = dirname(__DIR__) . '/' . $photo['imageUrl'];
                    if (file_exists($filePath)) {
                        @unlink($filePath);
                    }
                }
            } else {
                $newPhotos[] = $photo;
            }
        }

        if (!$found) {
            http_response_code(404);
            echo json_encode(['error' => 'Photo not found']);
            exit;
        }

        $data['photos'] = $newPhotos;
        saveData($data);

        echo json_encode(['success' => true, 'message' => 'Photo deleted successfully']);
        break;

    // ────────────────────────────────────────────────────────
    // POST: Delete entire category
    // ────────────────────────────────────────────────────────
    case 'delete-category':
        if ($method !== 'POST') { http_response_code(405); echo json_encode(['error' => 'Method not allowed']); exit; }
        
        $user = requireAuth();

        $input = json_decode(file_get_contents('php://input'), true);
        $categoryName = isset($input['category']) ? $input['category'] : (isset($_POST['category']) ? $_POST['category'] : '');

        if (!$categoryName) {
            http_response_code(400);
            echo json_encode(['error' => 'Category name is required']);
            exit;
        }

        $data = loadData();
        $deletedCount = 0;
        $newPhotos = [];

        foreach ($data['photos'] as $photo) {
            if (isset($photo['category']) && $photo['category'] === $categoryName) {
                $deletedCount++;
                // Delete file from disk
                if (!empty($photo['imageUrl']) && strpos($photo['imageUrl'], 'http') !== 0) {
                    $filePath = dirname(__DIR__) . '/' . $photo['imageUrl'];
                    if (file_exists($filePath)) {
                        @unlink($filePath);
                    }
                }
            } else {
                $newPhotos[] = $photo;
            }
        }

        $data['photos'] = $newPhotos;

        // Remove category description too
        $newCats = [];
        foreach ($data['categories'] as $cat) {
            if (!(isset($cat['category']) && $cat['category'] === $categoryName)) {
                $newCats[] = $cat;
            }
        }
        $data['categories'] = $newCats;

        // Delete folder from disk
        $safeFolder = sanitizeFolderName($categoryName);
        $folderPath = IMAGES_DIR . '/' . $safeFolder;
        if (is_dir($folderPath)) {
            // Recursively delete folder contents
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($folderPath, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach ($files as $fileinfo) {
                $action = ($fileinfo->isDir() ? 'rmdir' : 'unlink');
                @$action($fileinfo->getRealPath());
            }
            @rmdir($folderPath);
        }

        saveData($data);

        echo json_encode([
            'success' => true,
            'message' => "Deleted {$deletedCount} photo(s) in category \"{$categoryName}\"",
            'deletedCount' => $deletedCount,
        ]);
        break;

    // ────────────────────────────────────────────────────────
    // POST: Toggle featured status
    // ────────────────────────────────────────────────────────
    case 'toggle-featured':
        if ($method !== 'POST') { http_response_code(405); echo json_encode(['error' => 'Method not allowed']); exit; }
        
        $user = requireAuth();

        $input = json_decode(file_get_contents('php://input'), true);
        $id = isset($input['id']) ? $input['id'] : '';
        $featured = isset($input['featured']) ? (bool)$input['featured'] : false;

        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'Photo ID is required']);
            exit;
        }

        $data = loadData();
        $found = false;
        $updatedPhoto = null;

        foreach ($data['photos'] as &$photo) {
            if (isset($photo['_id']) && $photo['_id'] === $id) {
                $photo['featured'] = $featured;
                $found = true;
                $updatedPhoto = $photo;
                break;
            }
        }
        unset($photo);

        if (!$found) {
            http_response_code(404);
            echo json_encode(['error' => 'Photo not found']);
            exit;
        }

        saveData($data);
        echo json_encode(['success' => true, 'photo' => $updatedPhoto]);
        break;

    // ────────────────────────────────────────────────────────
    // POST: Update category description
    // ────────────────────────────────────────────────────────
    case 'update-description':
        if ($method !== 'POST') { http_response_code(405); echo json_encode(['error' => 'Method not allowed']); exit; }
        
        $user = requireAuth();

        $input = json_decode(file_get_contents('php://input'), true);
        $categoryName = isset($input['category']) ? trim($input['category']) : '';
        $description = isset($input['description']) ? trim($input['description']) : '';

        if (!$categoryName) {
            http_response_code(400);
            echo json_encode(['error' => 'Category name is required']);
            exit;
        }

        $data = loadData();

        $found = false;
        foreach ($data['categories'] as &$cat) {
            if (isset($cat['category']) && strtolower($cat['category']) === strtolower($categoryName)) {
                $cat['category'] = $categoryName; // sync exact casing
                $cat['description'] = $description;
                $cat['updatedAt'] = date('c');
                $found = true;
                break;
            }
        }
        unset($cat);

        if (!$found) {
            $data['categories'][] = [
                'category' => $categoryName,
                'description' => $description,
                'updatedAt' => date('c'),
            ];
        }

        saveData($data);

        echo json_encode([
            'success' => true,
            'message' => "Description for category \"{$categoryName}\" updated successfully",
        ]);
        break;

    // ────────────────────────────────────────────────────────
    // Unknown action
    // ────────────────────────────────────────────────────────
    default:
        http_response_code(400);
        echo json_encode([
            'error' => 'Invalid or missing action parameter',
            'available_actions' => ['list', 'categories', 'category-descriptions', 'upload', 'delete', 'delete-category', 'toggle-featured', 'update-description'],
        ]);
        break;
}
